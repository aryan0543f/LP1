import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Pass-I assembler for a simple pseudo-machine (object-oriented).
 * Produces symtab.txt and intermediate.txt from a source file.
 *
 * Usage:
 * 1. Place your source file in the same folder (default "source.asm").
 * 2. Compile: javac Pass1Assembler.java
 * 3. Run:     java Pass1Assembler
 *
 * Source line format (common):
 *  Label   Opcode   Operand   (Label is optional; if absent line should start with whitespace or tab)
 *  Example:
 *  COPY    START    1000
 *          LDA      ALPHA
 *  ALPHA   WORD     3
 *          END
 *
 * Comments: Lines starting with '.' are ignored.
 */
public class Pass1Assembler {

    // Small OPTAB: mnemonic -> instruction size (bytes)
    static class OpcodeEntry {
        String mnemonic;
        int sizeBytes;
        OpcodeEntry(String m, int s) { mnemonic = m; sizeBytes = s; }
    }

    static final Map<String, OpcodeEntry> OPTAB = new HashMap<>();
    static {
        // Example instruction set (assume 3-byte simple instructions)
        OPTAB.put("LDA", new OpcodeEntry("LDA", 3));
        OPTAB.put("STA", new OpcodeEntry("STA", 3));
        OPTAB.put("ADD", new OpcodeEntry("ADD", 3));
        OPTAB.put("SUB", new OpcodeEntry("SUB", 3));
        OPTAB.put("LDCH", new OpcodeEntry("LDCH", 3));
        OPTAB.put("STCH", new OpcodeEntry("STCH", 3));
        OPTAB.put("J", new OpcodeEntry("J", 3));
        OPTAB.put("COMP", new OpcodeEntry("COMP", 3));
        // you can add more mnemonics here
    }

    // Symbol entry
    static class Symbol {
        String name;
        int address; // integer address
        Symbol(String n, int a) { name = n; address = a; }
    }

    private final Map<String, Symbol> symtab = new LinkedHashMap<>(); // preserve insertion order
    private final List<String> intermediateLines = new ArrayList<>(); // LOC<TAB>LABEL<TAB>OP<TAB>OPERAND
    private int startAddress = 0;
    private int locctr = 0;
    private String programName = "";

    // Helper: parse a numeric token as hex (if hex digits) or decimal
    private static int parseNumber(String token) {
        if (token == null) return -1;
        token = token.trim();
        if (token.isEmpty() || token.equals("-")) return -1;
        try {
            // if token contains non-digit except A-F -> treat as decimal if not valid hex
            if (token.matches("^[0-9A-Fa-f]+$")) {
                return Integer.parseInt(token, 16);
            } else if (token.startsWith("0x") || token.startsWith("0X")) {
                return Integer.parseInt(token.substring(2), 16);
            } else {
                return Integer.parseInt(token); // decimal
            }
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // Compute size in bytes for BYTE operand C'...' or X'...'
    private static int byteOperandSize(String operand) {
        if (operand == null) return 0;
        operand = operand.trim();
        if (operand.startsWith("C'") && operand.endsWith("'") && operand.length() >= 3) {
            String inner = operand.substring(2, operand.length() - 1);
            return inner.length();
        } else if (operand.startsWith("X'") && operand.endsWith("'") && operand.length() >= 3) {
            String inner = operand.substring(2, operand.length() - 1);
            // each two hex digits = 1 byte -> length/2 (round up)
            return (inner.length() + 1) / 2;
        } else {
            // not a standard constant; treat as one byte by default
            return 1;
        }
    }

    // Process one source file (list of lines)
    public void processSource(List<String> sourceLines) {
        boolean started = false;
        for (int idx = 0; idx < sourceLines.size(); idx++) {
            String raw = sourceLines.get(idx);
            String line = raw;
            if (line == null) continue;
            // Trim end only — we need to detect leading whitespace
            if (line.trim().isEmpty()) {
                // Blank line -> record as intermediate with dashes
                intermediateLines.add("-\t-\t-\t-");
                continue;
            }

            // Comments start with '.' in many assemblers
            String trimmed = line.trim();
            if (trimmed.startsWith(".")) {
                // comment line -> record as intermediate comment (no LOC)
                intermediateLines.add("-\t.\t.\t.");
                continue;
            }

            boolean hasLabel = !(line.length() > 0 && (line.charAt(0) == ' ' || line.charAt(0) == '\t'));
            String label = "-";
            String opcode = "-";
            String operand = "-";

            // Tokenize depending on label presence
            if (hasLabel) {
                // split into at most 3 parts: label, opcode, operand (operand may contain spaces)
                String[] parts = line.trim().split("\\s+", 3);
                label = parts.length > 0 ? parts[0] : "-";
                opcode = parts.length > 1 ? parts[1] : "-";
                operand = parts.length > 2 ? parts[2] : "-";
            } else {
                // no label: split into at most 2 parts: opcode, operand
                String[] parts = line.trim().split("\\s+", 2);
                opcode = parts.length > 0 ? parts[0] : "-";
                operand = parts.length > 1 ? parts[1] : "-";
            }

            // Handle START directive
            if (opcode.equalsIgnoreCase("START")) {
                started = true;
                programName = hasLabel && !label.equals("-") ? label : "";
                int addr = parseNumber(operand);
                if (addr >= 0) {
                    startAddress = addr;
                    locctr = startAddress;
                } else {
                    locctr = 0;
                    startAddress = 0;
                }
                // Write intermediate entry with LOC
                intermediateLines.add(String.format("%04X\t%s\t%s\t%s", locctr, label, opcode, operand));
                continue;
            }

            // If not started and opcode isn't START, set locctr default 0
            if (!started) {
                startAddress = 0;
                locctr = 0;
                started = true;
            }

            // For END directive: write intermediate and finish (label and operand may be present)
            if (opcode.equalsIgnoreCase("END")) {
                // LOC field for END is '-': some conventions put last LOC; here we put '-'
                intermediateLines.add(String.format("-\t%s\t%s\t%s", label, opcode, operand));
                break; // Pass-I done
            }

            // Before allocating space, if a label is present, add to symbol table
            if (hasLabel && !label.equals("-")) {
                if (symtab.containsKey(label)) {
                    System.err.println("Error: Duplicate symbol '" + label + "' at source line " + (idx + 1));
                } else {
                    symtab.put(label, new Symbol(label, locctr));
                }
            }

            // Record intermediate line with current locctr (hex)
            intermediateLines.add(String.format("%04X\t%s\t%s\t%s", locctr, label, opcode, operand));

            // Update LOCCTR depending on opcode/directive
            String opUpper = opcode.toUpperCase();
            if (OPTAB.containsKey(opUpper)) {
                locctr += OPTAB.get(opUpper).sizeBytes;
            } else if (opUpper.equals("WORD")) {
                locctr += 3;
            } else if (opUpper.equals("RESW")) {
                // operand is number of words
                int count = parseNumber(operand);
                if (count < 0) count = 0;
                locctr += 3 * count;
            } else if (opUpper.equals("RESB")) {
                int count = parseNumber(operand);
                if (count < 0) count = 0;
                locctr += count;
            } else if (opUpper.equals("BYTE")) {
                int size = byteOperandSize(operand);
                locctr += size;
            } else {
                // Unknown opcode: report warning and assume 0 bytes to continue
                System.err.println("Warning: Unknown opcode '" + opcode + "' at source line " + (idx + 1) + ". LOCCTR unchanged.");
            }
        } // end for

        // After pass, write tables to files
        try {
            writeIntermediateFile("intermediate.txt");
            writeSymtabFile("symtab.txt");
            System.out.println("Pass-I completed. Files generated: intermediate.txt, symtab.txt");
        } catch (IOException e) {
            System.err.println("IO Error writing output files: " + e.getMessage());
        }
    }

    private void writeIntermediateFile(String filename) throws IOException {
        List<String> out = new ArrayList<>();
        out.add("LOC\tLABEL\tOPCODE\tOPERAND");
        out.addAll(intermediateLines);
        Files.write(Paths.get(filename), out);
    }

    private void writeSymtabFile(String filename) throws IOException {
        List<String> out = new ArrayList<>();
        for (Symbol s : symtab.values()) {
            out.add(String.format("%s\t%04X", s.name, s.address));
        }
        Files.write(Paths.get(filename), out);
    }

    // Simple utility to read a file into lines (or use default sample)
    public static List<String> readSourceFile(String filename) throws IOException {
        Path p = Paths.get(filename);
        if (!Files.exists(p)) {
            throw new FileNotFoundException("Source file '" + filename + "' not found.");
        }
        return Files.readAllLines(p);
    }

    // Sample driver
    public static void main(String[] args) {
        String sourceFile = "source.asm";
        System.out.println("Pass-I Assembler (pseudo-machine)");
        System.out.println("Reading source file: " + sourceFile);

        try {
            List<String> lines = readSourceFile(sourceFile);
            Pass1Assembler asm = new Pass1Assembler();
            asm.processSource(lines);

            // Print symbol table to console (for quick inspection)
            System.out.println("\nSymbol Table (symtab.txt):");
            for (Symbol s : asm.symtab.values()) {
                System.out.printf("%s -> %04X\n", s.name, s.address);
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            System.err.println("Create a file named 'source.asm' in the same folder as this program.");
            System.err.println("Example source.asm content (copy/paste):\n");
            System.err.println("COPY    START   1000");
            System.err.println("        LDA     ALPHA");
            System.err.println("        ADD     BETA");
            System.err.println("ALPHA   WORD    5");
            System.err.println("BETA    RESW    1");
            System.err.println("        BYTE    C'Z'");
            System.err.println("        END     -");
        }
    }
}
