
import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Pass-II assembler for a simple pseudo-machine (SIC-like). - Reads
 * intermediate file and symbol table from Pass-I. - Uses an internal OPTAB. -
 * Produces listing, object code lines and object program (H/T/E records).
 *
 * Expected input formats: symtab.txt: LABEL ADDRESS intermediate.txt:
 * LOCCTR<TAB>LABEL<TAB>OPCODE<TAB>OPERAND
 *
 * Note: This is a teaching/example implementation — extend for full ISA
 * features.
 */
public class PassIIAssembler {

    // Simple OPTAB: mnemonic -> opcode (hex string, 2 chars)
    private static final Map<String, String> OPTAB = new HashMap<>();

    static {
        // Example SIC-like opcodes
        OPTAB.put("LDA", "00");
        OPTAB.put("STA", "0C");
        OPTAB.put("LDCH", "50");
        OPTAB.put("STCH", "54");
        OPTAB.put("ADD", "18");
        OPTAB.put("SUB", "1C");
        OPTAB.put("MUL", "20");
        OPTAB.put("DIV", "24");
        OPTAB.put("COMP", "28");
        OPTAB.put("J", "3C");
        OPTAB.put("JEQ", "30");
        OPTAB.put("JGT", "34");
        OPTAB.put("JLT", "38");
        // Add more mnemonics as required
    }

    // Symbol table loaded from file: label -> address (integer)
    private final Map<String, Integer> symtab = new HashMap<>();

    // Stores listing entries
    private final List<ListingEntry> listing = new ArrayList<>();

    // For object program Text record building
    private final List<TextRecord> textRecords = new ArrayList<>();

    // Program name, start address, program length
    private String programName = "------";
    private int startAddress = 0;
    private int programLength = 0;

    // Inner classes
    private static class ListingEntry {

        int loc;            // location (int), -1 if none
        String label;
        String opcode;
        String operand;
        String objectCode;  // hex string or empty

        ListingEntry(int loc, String label, String opcode, String operand, String objectCode) {
            this.loc = loc;
            this.label = label;
            this.opcode = opcode;
            this.operand = operand;
            this.objectCode = objectCode;
        }
    }

    private static class TextRecord {

        int startAddr;              // start address of record
        final StringBuilder data;   // concatenated object codes hex (no separators)
        int lengthBytes;            // length in bytes

        TextRecord(int startAddr) {
            this.startAddr = startAddr;
            this.data = new StringBuilder();
            this.lengthBytes = 0;
        }

        boolean canAddBytes(int bytesToAdd) {
            return (lengthBytes + bytesToAdd) <= 30; // standard text record size limit
        }

        void addObjectCode(String objCode) {
            if (objCode == null || objCode.isEmpty()) {
                return;
            }
            data.append(objCode);
            lengthBytes += objCode.length() / 2;
        }

        boolean isEmpty() {
            return lengthBytes == 0;
        }

        String toRecordString() {
            // Format: T<start(6 hex)><length(2 hex)><data...>
            return String.format("T%06X%02X%s", startAddr, lengthBytes, data.toString());
        }
    }

    // Helper to parse hex (allow hex or decimal)
    private static int parseNumber(String token) {
        token = token.trim();
        if (token.isEmpty() || token.equals("-")) {
            return -1;
        }
        try {
            if (token.matches("^[0-9A-Fa-f]+$")) {
                // pure hex digits -> interpret as hex
                return Integer.parseInt(token, 16);
            } else if (token.startsWith("0x") || token.startsWith("0X")) {
                return Integer.parseInt(token.substring(2), 16);
            } else {
                // decimal fallback
                return Integer.parseInt(token);
            }
        } catch (NumberFormatException e) {
            // fallback: try decimal
            try {
                return Integer.parseInt(token);
            } catch (NumberFormatException ex) {
                return -1;
            }
        }
    }

    // Load symbol table from file
    private void loadSymtab(String symtabFile) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(symtabFile));
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) {
                continue;
            }
            String[] parts = line.split("\\s+");
            if (parts.length >= 2) {
                String label = parts[0];
                int addr = parseNumber(parts[1]);
                if (addr >= 0) {
                    symtab.put(label, addr);
                }
            }
        }
    }

    // Main pass2 routine: reads intermediate file and generates listing + object code
    public void pass2(String intermediateFile) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(intermediateFile));

        TextRecord currentText = null;

        for (String line : lines) {
            if (line.trim().isEmpty()) {
                continue;
            }
            // Expected format: LOCCTR<TAB>LABEL<TAB>OPCODE<TAB>OPERAND
            String[] parts = line.split("\t");
            // Ensure array length = 4 by padding missing columns with '-'
            String locField = parts.length > 0 ? parts[0].trim() : "-";
            String label = parts.length > 1 ? parts[1].trim() : "-";
            String opcode = parts.length > 2 ? parts[2].trim() : "-";
            String operand = parts.length > 3 ? parts[3].trim() : "-";

            int loc = locField.equals("-") ? -1 : parseNumber(locField);

            // If START directive, set program name and start address
            if ("START".equalsIgnoreCase(opcode)) {
                programName = (label != null && !label.equals("-")) ? label : programName;
                startAddress = (operand != null && !operand.equals("-")) ? parseNumber(operand) : 0;
                listing.add(new ListingEntry(loc, label, opcode, operand, ""));
                // Initialize first text record start address after START (will be set on first object code)
                continue;
            }

            // If END: finalize
            if ("END".equalsIgnoreCase(opcode)) {
                listing.add(new ListingEntry(loc, label, opcode, operand, ""));
                // Close current text record (if any)
                if (currentText != null && !currentText.isEmpty()) {
                    textRecords.add(currentText);
                    currentText = null;
                }
                // compute program length as last loc - startAddress (approx)
                // get last non-empty LOC from listing or lines
                int lastAddr = findLastAddress(lines);
                programLength = (lastAddr >= 0) ? lastAddr - startAddress : 0;
                continue;
            }

            String objCode = "";

            // Handle directives
            if ("WORD".equalsIgnoreCase(opcode)) {
                // 3 bytes integer
                int val = parseNumber(operand);
                if (val < 0) {
                    val = 0;
                }
                objCode = String.format("%06X", val & 0xFFFFFF);
            } else if ("BYTE".equalsIgnoreCase(opcode)) {
                // Operand formats: C'EOF' or X'F1' etc.
                objCode = generateByteObject(operand);
            } else if ("RESW".equalsIgnoreCase(opcode) || "RESB".equalsIgnoreCase(opcode)) {
                // No object code; reserves memory
                objCode = "";
                // when encountering a reservation, terminate current text record
                if (currentText != null && !currentText.isEmpty()) {
                    textRecords.add(currentText);
                }
                currentText = null;
            } else {
                // Instruction (look up in OPTAB)
                String opUpper = opcode.toUpperCase();
                if (OPTAB.containsKey(opUpper)) {
                    String opcodeHex = OPTAB.get(opUpper); // two hex chars
                    boolean indexed = false;
                    String operandToken = operand;

                    if (operandToken != null && operandToken.endsWith(",X")) {
                        indexed = true;
                        operandToken = operandToken.substring(0, operandToken.length() - 2).trim();
                    }

                    int addr = 0;
                    if (operandToken == null || operandToken.equals("-") || operandToken.isEmpty()) {
                        addr = 0;
                    } else if (isNumericLiteral(operandToken)) {
                        addr = parseNumber(operandToken);
                    } else {
                        Integer symAddr = symtab.get(operandToken);
                        if (symAddr == null) {
                            System.err.println("Error: Undefined symbol '" + operandToken + "' at LOC " + String.format("%04X", loc));
                            addr = 0;
                        } else {
                            addr = symAddr;
                        }
                    }

                    // If indexed, set index bit (for this pseudo-machine we set bit 15)
                    // produce 3-byte instruction: opcode(1 byte) + address(2 bytes) -> total 3 bytes
                    // we will create object code as: opcode(1 byte) + 3 hex digits of address
                    // For simplicity produce opcode (2 hex) + address (4 hex) => 3 bytes (6 hex chars)
                    int addressField = addr & 0xFFFF;
                    if (indexed) {
                        addressField = addressField | 0x8000; // set highest bit in 16-bit address
                    }

                    objCode = String.format("%02X%04X", Integer.parseInt(opcodeHex, 16) & 0xFF, addressField & 0xFFFF);
                } else {
                    // unknown opcode - treat as no object code (or could be assembler directive)
                    objCode = "";
                }
            }

            // Add to listing
            listing.add(new ListingEntry(loc, label, opcode, operand, objCode));

            // Build Text Records:
            if (objCode != null && !objCode.isEmpty()) {
                if (currentText == null) {
                    currentText = new TextRecord(loc);
                }
                // If this object code is not contiguous with current text record, flush and start new
                if (currentText.isEmpty()) {
                    currentText.startAddr = loc;
                } else {
                    // Contiguity check: previous end addr = startAddr + lengthBytes
                    int prevEnd = currentText.startAddr + currentText.lengthBytes;
                    if (prevEnd != loc) {
                        // non-contiguous -> flush
                        textRecords.add(currentText);
                        currentText = new TextRecord(loc);
                    }
                }

                int bytesToAdd = objCode.length() / 2;
                if (!currentText.canAddBytes(bytesToAdd)) {
                    // flush current and start new
                    textRecords.add(currentText);
                    currentText = new TextRecord(loc);
                }
                currentText.addObjectCode(objCode);
            }
        }

        // finalize last text record
        if (!textRecords.isEmpty()) {
            // nothing
        }
        // If we have a trailing currentText that is not added yet:
        if (!textRecords.stream().anyMatch(tr -> tr == null)) {
            // ensure we add last currentText if exists and non-empty
            // (we can't reference currentText here - restructure to keep reference)
        }
        // Simpler: re-run to add final one: last element of listing with object code might be in currentText variable earlier.
        // Instead we tracked and added when encountering END and RESW/RESB; but to be safe, recompute:
        // We'll derive startAddress and programLength by scanning listing
        computeProgramLengthAndFinalizeTextRecords(); // will add any outstanding text records recorded during pass

    }

    // Helper to find last address from intermediate lines
    private int findLastAddress(List<String> lines) {
        int last = -1;
        for (String l : lines) {
            if (l.trim().isEmpty()) {
                continue;
            }
            String[] p = l.split("\t");
            String locField = p.length > 0 ? p[0].trim() : "-";
            int loc = locField.equals("-") ? -1 : parseNumber(locField);
            if (loc >= 0) {
                last = loc;
            }
        }
        return last;
    }

    // This method rebuilds text records from the listing to ensure finalization and correctness.
    private void computeProgramLengthAndFinalizeTextRecords() {
        textRecords.clear();
        TextRecord currentText = null;
        int lastAddr = -1;

        for (ListingEntry le : listing) {
            if (le.loc >= 0) {
                lastAddr = le.loc;
            }
            String obj = le.objectCode;
            if (obj != null && !obj.isEmpty()) {
                if (currentText == null) {
                    currentText = new TextRecord(le.loc);
                } else {
                    int prevEnd = currentText.startAddr + currentText.lengthBytes;
                    if (prevEnd != le.loc) {
                        // flush
                        if (!currentText.isEmpty()) {
                            textRecords.add(currentText);
                        }
                        currentText = new TextRecord(le.loc);
                    }
                }
                int bytes = obj.length() / 2;
                if (!currentText.canAddBytes(bytes)) {
                    if (!currentText.isEmpty()) {
                        textRecords.add(currentText);
                    }
                    currentText = new TextRecord(le.loc);
                }
                currentText.addObjectCode(obj);
            } else {
                // reservation or directive -> flush current
                if (currentText != null && !currentText.isEmpty()) {
                    textRecords.add(currentText);
                }
                currentText = null;
            }
        }
        if (currentText != null && !currentText.isEmpty()) {
            textRecords.add(currentText);
        }

        if (lastAddr >= 0) {
            programLength = lastAddr - startAddress;
            if (programLength < 0) {
                programLength = 0;
            }
        }
    }

    // Generate object for BYTE directive
    private static String generateByteObject(String operand) {
        if (operand == null) {
            return "";
        }
        operand = operand.trim();
        if (operand.startsWith("C'") && operand.endsWith("'")) {
            String inner = operand.substring(2, operand.length() - 1);
            StringBuilder sb = new StringBuilder();
            for (char c : inner.toCharArray()) {
                sb.append(String.format("%02X", (int) c));
            }
            return sb.toString();
        } else if (operand.startsWith("X'") && operand.endsWith("'")) {
            String inner = operand.substring(2, operand.length() - 1);
            // validate hex length even
            if (inner.length() % 2 != 0) {
                inner = "0" + inner;
            }
            return inner.toUpperCase();
        } else {
            // unknown format - try to parse as numeric byte(s)
            int val = parseNumber(operand);
            if (val < 0) {
                val = 0;
            }
            // minimal: produce hex representation in bytes (as WORD would do)
            return String.format("%02X", val & 0xFF);
        }
    }

    private static boolean isNumericLiteral(String tok) {
        if (tok == null) {
            return false;
        }
        tok = tok.trim();
        return tok.matches("^-?\\d+$") || tok.matches("^[0-9A-Fa-f]+$") || tok.startsWith("0x") || tok.startsWith("0X");
    }

    // Write listing file
    public void writeListing(String filename) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(filename))) {
            bw.write(String.format("%-8s %-8s %-8s %-12s %-12s%n", "LOC", "LABEL", "OPCODE", "OPERAND", "OBJCODE"));
            for (ListingEntry le : listing) {
                String locStr = (le.loc >= 0) ? String.format("%04X", le.loc) : "----";
                bw.write(String.format("%-8s %-8s %-8s %-12s %-12s%n",
                        locStr, le.label, le.opcode, le.operand, le.objectCode));
            }
        }
    }

    // Write object program (H/T/E records) to file
    public void writeObjectProgram(String filename) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(filename))) {
            // Header record: H<programName(6)><startAddr(6)><length(6)>
            bw.write(String.format("H%-6s%06X%06X%n", programName.length() > 6 ? programName.substring(0, 6) : programName, startAddress, programLength));

            // Text records
            for (TextRecord tr : textRecords) {
                bw.write(tr.toRecordString());
                bw.write(System.lineSeparator());
            }

            // End record: E<startAddr(6)>
            bw.write(String.format("E%06X%n", startAddress));
        }
    }

    // Write object code per-line (for easy reading)
    public void writeObjectCodeLines(String filename) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(filename))) {
            for (ListingEntry le : listing) {
                if (le.objectCode != null && !le.objectCode.isEmpty()) {
                    bw.write(String.format("%04X\t%s%n", le.loc, le.objectCode));
                }
            }
        }
    }

    // Entry point
    public static void main(String[] args) {
        String symtabFile = "symtab.txt";
        String intermediateFile = "intermediate.txt";
        String listingOut = "pass2_listing.txt";
        String objectProgramOut = "object_program.txt";
        String objectLinesOut = "object_lines.txt";

        PassIIAssembler assembler = new PassIIAssembler();

        try {
            // load symbol table
            assembler.loadSymtab(symtabFile);
            System.out.println("Loaded SYMTAB entries: " + assembler.symtab.size());

            // process intermediate and generate object code/listing
            assembler.pass2(intermediateFile);
            assembler.computeProgramLengthAndFinalizeTextRecords(); // ensure finalization after pass

            // write outputs
            assembler.writeListing(listingOut);
            assembler.writeObjectProgram(objectProgramOut);
            assembler.writeObjectCodeLines(objectLinesOut);

            System.out.println("Pass-II completed.");
            System.out.println("Listing written to: " + listingOut);
            System.out.println("Object program written to: " + objectProgramOut);
            System.out.println("Per-instruction object lines written to: " + objectLinesOut);
        } catch (IOException e) {
            System.err.println("IO Error: " + e.getMessage());
        }
    }
}
